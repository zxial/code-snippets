=== WP APP JSON ===
Contributors: zxial
Donate link: 
Tags: Mobile, APP, JSON, Interface
Requires at least: 3.0
Tested up to: 3.8.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The WP-APP-JSON is a plugin that provide json data to mobile apps, you can use
keywords to search your posts and get detail webpage.

== Description ==

This plugin provides JSON data to mobile APPs. Here's the scenarios that you
could use this plugin: you want to develop a mobile app or app on mac, and the
app is to show the list of your blogs(in category, tag, or keywords), after
the app user click one item in the blog list, you would like to show him the
detail page of the item, but the logos/banners/sidebar of blog is suitable
only for a desktop other than a mobile device or you want to do something
different. In the case here, wp_app_json mayble could help.



Code: 
Author: Zxial
Web: http://zxial.me


== Installation ==


1. Upload the zip to `/wp-content/plugins/` dir
2. Unzip the file and activate the plugin in Wordpress.
3. Enjoy

== Screenshots ==


== Changelog ==

= 1.0 =
* Initial version
